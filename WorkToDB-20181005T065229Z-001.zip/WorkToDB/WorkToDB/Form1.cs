﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WorkToDB
{
    public partial class FormAuto : Form
    {
        public FormAuto()
        {
            InitializeComponent();
        }

        private void BtnAuto_Click(object sender, EventArgs e)


        {

        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormReg formReg = new FormReg();
            formReg.Show();

        }

        private void FormAuto_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();

        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            SqlConnection sqlConnect = new SqlConnection("Data Source=CN408-02;Initial Catalog=AutoSalon;Persist Security Info=True;User ID=sa;Password=123");
            sqlConnect.Open();
            SqlCommand sqlQuery = new SqlCommand("SELECT * FROM [dbo].[User] Where Login='" + TBLogin.Text + "' AND Password='" + TBPassword.Text + "'", sqlConnect);

            SqlDataReader sqlQueryReader = null;
            sqlQueryReader = sqlQuery.ExecuteReader();

            if (sqlQueryReader.HasRows)
            {
                sqlQueryReader.Read();
                if ((sqlQueryReader.GetValue(0).ToString() == TBLogin.Text) &&
                    (sqlQueryReader.GetValue(1).ToString() == TBPassword.Text))
                {
                    if (sqlQueryReader.GetValue(2).ToString() == "User")
                    {
                        MessageBox.Show("You are autorized as a User.");
                    }
                    else if (sqlQueryReader.GetValue(2).ToString() == "Director")
                    {
                        FormDirector formD = new FormDirector();
                        formD.Show();
                    }
                }


            }
            else MessageBox.Show("Wrong password!");
        }

        private void информацияОКомпанииToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }
    }
}
    
    
