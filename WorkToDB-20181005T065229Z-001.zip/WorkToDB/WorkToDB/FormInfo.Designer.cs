﻿namespace WorkToDB
{
    partial class FormInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabInfo = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabinfo2 = new System.Windows.Forms.TabPage();
            this.email = new System.Windows.Forms.Label();
            this.tel = new System.Windows.Forms.Label();
            this.adres = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabInfo.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WorkToDB.Properties.Resources.Chevrolet_logo_2013_2560x1440;
            this.pictureBox1.Location = new System.Drawing.Point(12, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(166, 138);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F);
            this.label1.Location = new System.Drawing.Point(184, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(341, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Информация о компании:";
            // 
            // tabInfo
            // 
            this.tabInfo.Controls.Add(this.tabPage1);
            this.tabInfo.Controls.Add(this.tabinfo2);
            this.tabInfo.Location = new System.Drawing.Point(54, 191);
            this.tabInfo.Name = "tabInfo";
            this.tabInfo.SelectedIndex = 0;
            this.tabInfo.Size = new System.Drawing.Size(451, 159);
            this.tabInfo.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.adres);
            this.tabPage1.Controls.Add(this.tel);
            this.tabPage1.Controls.Add(this.email);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(443, 133);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Контакты";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabinfo2
            // 
            this.tabinfo2.Location = new System.Drawing.Point(4, 22);
            this.tabinfo2.Name = "tabinfo2";
            this.tabinfo2.Padding = new System.Windows.Forms.Padding(3);
            this.tabinfo2.Size = new System.Drawing.Size(443, 133);
            this.tabinfo2.TabIndex = 1;
            this.tabinfo2.Text = "Общая информация";
            this.tabinfo2.UseVisualStyleBackColor = true;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.email.Location = new System.Drawing.Point(17, 73);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(260, 24);
            this.email.TabIndex = 0;
            this.email.Text = "E-mail: shevroletauto@mail.ru";
            this.email.Click += new System.EventHandler(this.email_Click);
            // 
            // tel
            // 
            this.tel.AutoSize = true;
            this.tel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.tel.Location = new System.Drawing.Point(17, 97);
            this.tel.Name = "tel";
            this.tel.Size = new System.Drawing.Size(321, 24);
            this.tel.TabIndex = 1;
            this.tel.Text = "Справочная служба: 8-800-55-35-35";
            // 
            // adres
            // 
            this.adres.AutoSize = true;
            this.adres.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F);
            this.adres.Location = new System.Drawing.Point(6, 14);
            this.adres.Name = "adres";
            this.adres.Size = new System.Drawing.Size(418, 48);
            this.adres.TabIndex = 2;
            this.adres.Text = "Адрес салона \r\nм. Войковская, Москва, ул. Коптевская, д.69А";
            // 
            // FormInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(553, 394);
            this.Controls.Add(this.tabInfo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.MaximumSize = new System.Drawing.Size(569, 433);
            this.MinimumSize = new System.Drawing.Size(569, 433);
            this.Name = "FormInfo";
            this.Text = "Информация о компании";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabInfo.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabInfo;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.TabPage tabinfo2;
        private System.Windows.Forms.Label tel;
        private System.Windows.Forms.Label adres;
    }
}